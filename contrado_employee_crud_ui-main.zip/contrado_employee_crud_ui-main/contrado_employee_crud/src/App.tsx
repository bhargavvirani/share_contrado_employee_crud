import React from 'react';
import logo from './logo.svg';
import './App.css';
import Home from './component/Home';

function App() {
  return (
    <Home></Home>
  );
}

export default App;
