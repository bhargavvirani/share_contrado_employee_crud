import React, { useCallback, useEffect, useState } from "react";
import { IEmployee } from "./Employee.type";
import {
  DataGrid,
  GridColDef,
  GridColumnMenu,
  GridColumnMenuProps,
} from "@mui/x-data-grid";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
import DeleteIcon from "@mui/icons-material/Delete";
import IconButton from "@mui/material/IconButton";
import ModeIcon from "@mui/icons-material/Mode";
import { FormControl } from "@mui/material";
import TextField from "@mui/material/TextField";
import { DateField } from "@mui/x-date-pickers/DateField";
import { DemoContainer } from "@mui/x-date-pickers/internals/demo";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import dayjs, { Dayjs } from "dayjs";
import { IInputEmployee } from "./Employee.type";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import InputLabel from "@mui/material/InputLabel";
import {
  getEmployeeList,
  addEmployee,
  editEmployee,
  deleteEmployee,
} from "./Employee.service";

const EmployeeList = () => {
  const [empList, setEmpList] = useState<IEmployee[]>([]);
  const [isFormVisiable, setIsFormVisiable] = useState(false);
  const [emp_Id, setEmp_Id] = useState(0);
  const [selectedDate, setSelectedDate] = React.useState<Dayjs | null>(
    dayjs("01/01/1900")
  );

  const [formData, setFormData] = useState({
    Emp_Tag_Number: "",
    First_Name: "",
    Last_Name: "",
    BirthDate: dayjs("01/01/1900"),
    Email: "",
    Department: "",
    Designation: "",
  });

  const columns: GridColDef[] = [
    { field: "Emp_Id", headerName: "Employee Id", width: 70, hideable: false },
    {
      field: "Emp_Tag_Number",
      headerName: "Employee Tag #",
      width: 130,
      hideable: false,
    },
    {
      field: "First_Name",
      headerName: "First Name",
      width: 130,
      hideable: false,
    },
    {
      field: "Last_Name",
      headerName: "Last Name",
      width: 130,
      hideable: false,
    },
    {
      field: "BirthDate",
      headerName: "BirthDate",
      width: 100,
      hideable: false,
    },
    { field: "Email", headerName: "Email", width: 160, hideable: false },
    {
      field: "Department",
      headerName: "Department",
      width: 100,
      hideable: false,
    },
    {
      field: "Designation",
      headerName: "Designation",
      width: 130,
      hideable: false,
    },
    { field: "Age", headerName: "Age", width: 70, hideable: false },
    {
      field: "actions",
      headerName: "Actions",
      width: 100,
      renderCell: (params) => {
        return (
          <Stack spacing={1} direction="row">
            <IconButton
              aria-label="edit"
              onClick={(e) => onEditClick(e, params.row)}
            >
              <ModeIcon />
            </IconButton>
            <IconButton
              aria-label="delete"
              onClick={(e) => onDeleteClick(e, params.row)}
            >
              <DeleteIcon />
            </IconButton>
          </Stack>
        );
      },
    },
  ];

  useEffect(() => {
    loadEmplloyeeList();
  }, [empList]);

  const OnPageLoad = useCallback(() => {
    setEmp_Id(0);
    setSelectedDate(dayjs("01/01/1900"));
    setFormData({
      Emp_Tag_Number: "",
      First_Name: "",
      Last_Name: "",
      BirthDate: dayjs("01/01/1900"),
      Email: "",
      Department: "",
      Designation: "",
    });
    setIsFormVisiable(false);
  }, []);

  async function loadEmplloyeeList() {
    let currentDT = dayjs().format("MM/DD/YYYY");
    var fecthedEmployeeList = await getEmployeeList();
    var lists: IEmployee[] = fecthedEmployeeList.map((emp: any) => {
      return {
        Emp_Id: emp.emp_Id,
        Emp_Tag_Number: emp.emp_Tag_Number,
        First_Name: emp.first_Name,
        Last_Name: emp.last_Name,
        Email: emp.email,
        Department: emp.department,
        Designation: emp.designation,
        BirthDate: dayjs(emp.birthDate).format("MM/DD/YYYY"),
        Age: dayjs(currentDT).diff(dayjs(emp.birthDate), "year"),
      };
    });
    setEmpList(lists);
  }

  const onDeleteClick = async (e: any, row: any) => {
    e.stopPropagation();
    const shouldDelete = window.confirm(
      "Are you sure you want to delete the record?"
    );
    if (shouldDelete) {
      await deleteEmployee(row.Emp_Id);
      await loadEmplloyeeList();
    }
  };

  const onEditClick = (e: any, row: any) => {
    e.stopPropagation();
    setIsFormVisiable(true);
    setEmp_Id(row.Emp_Id);
    setSelectedDate(dayjs(row?.BirthDate));
    setFormData({
      Emp_Tag_Number: row?.Emp_Tag_Number,
      First_Name: row?.First_Name,
      Last_Name: row?.Last_Name,
      BirthDate: dayjs(row?.BirthDate),
      Department: row?.Department,
      Designation: row?.Designation,
      Email: row?.Email,
    });
  };

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    let inputEmployeeData: IInputEmployee = {
      Emp_Id: emp_Id,
      Emp_Tag_Number: formData.Emp_Tag_Number,
      First_Name: formData.First_Name,
      Last_Name: formData.Last_Name,
      Email: formData.Email,
      Department: formData.Department,
      Designation: formData.Designation,
      BirthDate:
        selectedDate &&
        selectedDate !==
          dayjs(dayjs("01/01/1900").format("YYYY-MM-DDTHH:mm:ss.SSS[Z]"))
          ? dayjs(selectedDate.toDate()).format("YYYY-MM-DDTHH:mm:ss.SSS[Z]")
          : dayjs(formData.BirthDate.toDate()).format(
              "YYYY-MM-DDTHH:mm:ss.SSS[Z]"
            ),
    };
    if (emp_Id === 0) {
      await addEmployee(inputEmployeeData);
    }
    if (emp_Id !== 0) {
      await editEmployee(inputEmployeeData);
    }
    OnPageLoad();
  };

  const handleChange = (e: any) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  function CustomColumnMenu(props: GridColumnMenuProps) {
    return (
      <GridColumnMenu
        {...props}
        slots={{
          columnMenuColumnsItem: null,
        }}
      />
    );
  }

  const handleAddNewEmployeeOnClick = () => {
    setEmp_Id(0);
    setSelectedDate(dayjs("01/01/1900"));
    setFormData({
      Emp_Tag_Number: "",
      First_Name: "",
      Last_Name: "",
      BirthDate: dayjs("01/01/1900"),
      Email: "",
      Department: "",
      Designation: "",
    });
    setIsFormVisiable(true);
  };

  const handleOnClickCancel = () => {
    setIsFormVisiable(false);
    setEmp_Id(0);
    setSelectedDate(dayjs("01/01/1900"));
    setFormData({
      Emp_Tag_Number: "",
      First_Name: "",
      Last_Name: "",
      BirthDate: dayjs("01/01/1900"),
      Email: "",
      Department: "",
      Designation: "",
    });
    OnPageLoad();
  };

  const handleOnChangeSelectedDate = (date: any) => {
    setSelectedDate(date);
  };

  return (
    <>
      {
        <div style={{ width: "100%" }}>
          {!isFormVisiable && (
            <div style={{ height: 30 }}>
              <Button variant="contained" onClick={handleAddNewEmployeeOnClick}>
                Add New Employee
              </Button>
            </div>
          )}
          {isFormVisiable && (
            <div style={{ marginTop: 20 }}>
              <form onSubmit={handleSubmit}>
                <Stack spacing={1} direction="column">
                  <Stack spacing={1} direction="column">
                    <TextField
                      label="Employee Tag Number"
                      variant="outlined"
                      size="medium"
                      style={{ width: 500 }}
                      name="Emp_Tag_Number"
                      value={formData.Emp_Tag_Number}
                      onChange={handleChange}
                      inputProps={{
                        pattern: "^(?=.*[a-zA-Z])(?=.*[0-9])[a-zA-Z0-9]*$",
                      }}
                      helperText={
                        formData.Emp_Tag_Number === ""
                          ? ""
                          : !formData.Emp_Tag_Number.match(
                              "^(?=.*[a-zA-Z])(?=.*[0-9])[a-zA-Z0-9]*$"
                            )
                          ? "Should contain at least one alphabet and at least one number."
                          : ""
                      }
                      required
                    />
                    <TextField
                      label="First Name"
                      variant="outlined"
                      size="medium"
                      style={{ width: 500 }}
                      name="First_Name"
                      value={formData.First_Name}
                      onChange={handleChange}
                      required
                    />
                    <TextField
                      label="Last Name"
                      variant="outlined"
                      size="medium"
                      style={{ width: 500 }}
                      name="Last_Name"
                      value={formData.Last_Name}
                      onChange={handleChange}
                      required
                    />
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <DemoContainer components={["DateField"]}>
                        <DateField
                          label="BirthDate"
                          size="medium"
                          format="DD/MM/YYYY"
                          style={{ width: 500 }}
                          name="BirthDate"
                          value={formData.BirthDate}
                          onChange={(newValue) =>
                            handleOnChangeSelectedDate(newValue)
                          }
                          helperText={
                            formData.BirthDate >= dayjs("01/01/1900")
                              ? ""
                              : "BirthDate should be greater than 01/01/1900"
                          }
                          required
                        />
                      </DemoContainer>
                    </LocalizationProvider>
                    <TextField
                      label="Email"
                      variant="outlined"
                      size="medium"
                      style={{ width: 500 }}
                      name="Email"
                      type="email"
                      value={formData.Email}
                      onChange={handleChange}
                      required
                    />
                    <FormControl>
                      <InputLabel id="demo-simple-select-helper-label-department">
                        Department
                      </InputLabel>
                      <Select
                        labelId="demo-simple-select-helper-label-department"
                        id="demo-simple-select-helper-department"
                        value={formData.Department}
                        label="Department"
                        name="Department"
                        size="medium"
                        style={{ width: 500 }}
                        onChange={handleChange}
                      >
                        <MenuItem value={"Dev"}>Dev</MenuItem>
                        <MenuItem value={"QA"}>QA</MenuItem>
                        <MenuItem value={"SA"}>SA</MenuItem>
                        <MenuItem value={"Lead"}>BA</MenuItem>
                        <MenuItem value={"Scrum"}>Scrum</MenuItem>
                      </Select>
                    </FormControl>
                    <FormControl>
                      <InputLabel id="demo-simple-select-helper-label-designation">
                        Designation
                      </InputLabel>
                      <Select
                        labelId="demo-simple-select-helper-label-designation"
                        id="demo-simple-select-helper-designation"
                        value={formData.Designation}
                        label="Designation"
                        name="Designation"
                        size="medium"
                        style={{ width: 500 }}
                        onChange={handleChange}
                      >
                        <MenuItem value={"Trainee"}>Trainee</MenuItem>
                        <MenuItem value={"Associate"}>Associate</MenuItem>
                        <MenuItem value={"Senior"}>Senior</MenuItem>
                        <MenuItem value={"Lead"}>Lead</MenuItem>
                        <MenuItem value={"Manager"}>Manager</MenuItem>
                      </Select>
                    </FormControl>
                  </Stack>
                  <Stack spacing={1} direction="row">
                    <Button type="submit" variant="contained" color="primary">
                      Submit
                    </Button>
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={handleOnClickCancel}
                    >
                      Cancel
                    </Button>
                  </Stack>
                </Stack>
              </form>
            </div>
          )}
          {!isFormVisiable && (
            <div style={{ height: "100%", marginTop: 10 }}>
              <DataGrid
                getRowId={(row) => row.Emp_Id}
                rows={empList}
                columns={columns}
                slots={{ columnMenu: CustomColumnMenu }}
                columnVisibilityModel={{
                  Emp_Id: false,
                }}
                initialState={{
                  pagination: {
                    paginationModel: { page: 0, pageSize: 10 },
                  },
                }}
                pageSizeOptions={[10, 20, 40, 60, 80, 100]}
              />
            </div>
          )}
        </div>
      }
    </>
  );
};

export default EmployeeList;
