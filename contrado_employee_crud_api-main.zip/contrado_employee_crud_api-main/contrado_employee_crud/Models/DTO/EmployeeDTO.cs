﻿using System.ComponentModel.DataAnnotations;

namespace contrado_employee_crud.Models.DTO
{
    public class EmployeeDTO
    {
        [Required]
        [RegularExpression("^(?=.*[a-zA-Z])(?=.*[0-9])[a-zA-Z0-9]*$", ErrorMessage = "Should contain at least one alphabet and at least one number.")]
        public string Emp_Tag_Number { get; set; }

        [Required]
        public string First_Name { get; set; }

        [Required]
        public string Last_Name { get; set; }

        [Required]
        [EmailAddress(ErrorMessage = "Invalid email address.")]
        public string Email { get; set; }

        [Required]
        public string Department { get; set; }

        [Required]
        public DateTime BirthDate { get; set; }

        [Required]
        public string Designation { get; set; }
    }
}
