﻿using contrado_employee_crud.Models;

namespace contrado_employee_crud.Repositories
{
    public interface IEmployeeRepository
    {
        Task<IEnumerable<Employee>> GetAllEmployees();
        Task<Employee> GetEmployeeById(int emp_Id);
        Task AddEmployee(Employee employee);
        Task<bool> UpdateEmployee(Employee employee);
        Task<bool> DeleteEmployee(int emp_Id);
    }
}
