﻿using contrado_employee_crud.Models;
using Microsoft.EntityFrameworkCore;

namespace contrado_employee_crud.Repositories
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly EmpoyeeCrudDbContext _dbContext;

        public EmployeeRepository(EmpoyeeCrudDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task AddEmployee(Employee employee)
        {
            var createdEmployee = _dbContext.Employees.Add(employee);

            await _dbContext.SaveChangesAsync();
        }

        public async Task<bool> DeleteEmployee(int emp_Id)
        {
            var emp = await _dbContext.Employees.FindAsync(emp_Id);

            if (emp == null)
                return false;

            _dbContext.Employees.Remove(emp);
            await _dbContext.SaveChangesAsync();

            return true;
        }

        public async Task<IEnumerable<Employee>> GetAllEmployees()
        {
            return await _dbContext.Employees.ToListAsync();
        }

        public async Task<Employee> GetEmployeeById(int emp_Id)
        {
            return await _dbContext.Employees.FirstOrDefaultAsync(m => m.Emp_Id == emp_Id);
        }

        public async Task<bool> UpdateEmployee(Employee employee)
        {
            var emp = await _dbContext.Employees.FindAsync(employee.Emp_Id);

            if (emp == null)
                return false;

            emp.Emp_Tag_Number = employee.Emp_Tag_Number;
            emp.First_Name = employee.First_Name;
            emp.Last_Name = employee.Last_Name;
            emp.Email = employee.Email;
            emp.BirthDate = employee.BirthDate;
            emp.Department = employee.Department;
            emp.Designation = employee.Designation;

            await _dbContext.SaveChangesAsync();

            return true;
        }
    }
}
