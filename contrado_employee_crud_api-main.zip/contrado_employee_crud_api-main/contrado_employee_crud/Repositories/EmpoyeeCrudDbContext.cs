﻿using contrado_employee_crud.Models;
using Microsoft.EntityFrameworkCore;

namespace contrado_employee_crud.Repositories
{
    public class EmpoyeeCrudDbContext : DbContext
    {
        public EmpoyeeCrudDbContext(DbContextOptions<EmpoyeeCrudDbContext> options) : base(options)
        {
        }

        public DbSet<Employee> Employees { get; set; }

    }
}
